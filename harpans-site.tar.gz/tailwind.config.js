/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './templates/**/*.html',
    './core/templates/**/*.html',
    './team/templates/**/*.html',
    './blog/templates/**/*.html',
    './contact/templates/**/*.html',
  ],
  theme: {
    extend: {
      colors: {
        // Electric Startup Theme
        'primary': {
          50: '#faf5ff',
          100: '#f3e8ff',
          200: '#e9d5ff',
          300: '#d8b4fe',
          400: '#c084fc',
          500: '#a855f7',
          600: '#9333ea',  // Main primary
          700: '#7e22ce',
          800: '#6b21a8',
          900: '#581c87',
        },
        'secondary': {
          50: '#ecfeff',
          100: '#cffafe',
          200: '#a5f3fc',
          300: '#67e8f9',
          400: '#22d3ee',
          500: '#06b6d4',  // Main secondary (cyan)
          600: '#0891b2',
          700: '#0e7490',
          800: '#155e75',
          900: '#164e63',
        },
        'accent': {
          50: '#fffbeb',
          100: '#fef3c7',
          200: '#fde68a',
          300: '#fcd34d',
          400: '#fbbf24',
          500: '#f59e0b',  // Main accent (amber)
          600: '#d97706',
          700: '#b45309',
          800: '#92400e',
          900: '#78350f',
        },
      },
      backgroundImage: {
        'gradient-primary': 'linear-gradient(135deg, #9333ea 0%, #06b6d4 100%)',
        'gradient-hero': 'linear-gradient(135deg, #7c3aed 0%, #06b6d4 100%)',
        'gradient-cta': 'linear-gradient(135deg, #9333ea 0%, #7e22ce 100%)',
      },
      boxShadow: {
        'glow-primary': '0 0 20px rgba(147, 51, 234, 0.5)',
        'glow-secondary': '0 0 20px rgba(6, 182, 212, 0.5)',
        'glow-accent': '0 0 20px rgba(245, 158, 11, 0.5)',
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
  ],
}