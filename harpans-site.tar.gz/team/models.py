from django.db import models
from wagtail.models import Page, Orderable
from wagtail.fields import RichTextField
from wagtail.admin.panels import FieldPanel, InlinePanel
from modelcluster.fields import ParentalKey
from core.models import BasePage


class TeamMember(Orderable):
    """Teammedlem"""
    
    page = ParentalKey('team.TeamPage', related_name='team_members')
    
    name = models.CharField(max_length=255, verbose_name="Namn")
    title = models.CharField(max_length=255, verbose_name="Titel/Roll")
    bio = RichTextField(blank=True, verbose_name="Biografi")
    photo = models.ForeignKey(
        'wagtailimages.Image',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='+',
        verbose_name="Foto"
    )
    email = models.EmailField(blank=True, verbose_name="E-post")
    phone = models.CharField(max_length=50, blank=True, verbose_name="Telefon")
    linkedin_url = models.URLField(blank=True, verbose_name="LinkedIn URL")
    
    panels = [
        FieldPanel('name'),
        FieldPanel('title'),
        FieldPanel('bio'),
        FieldPanel('photo'),
        FieldPanel('email'),
        FieldPanel('phone'),
        FieldPanel('linkedin_url'),
    ]
    
    class Meta:
        verbose_name = "Teammedlem"
        verbose_name_plural = "Teammedlemmar"


class TeamPage(BasePage):
    """Om oss-sida med team"""
    
    intro = RichTextField(blank=True, verbose_name="Introduktion")
    
    content_panels = Page.content_panels + [
        FieldPanel('intro'),
        InlinePanel('team_members', label="Teammedlemmar"),
    ]
    
    class Meta:
        verbose_name = "Om oss"