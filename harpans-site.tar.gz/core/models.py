from django.db import models
from django.utils.text import slugify
from wagtail.models import Page
from wagtail.fields import RichTextField, StreamField
from wagtail.admin.panels import FieldPanel
from wagtail import blocks
from wagtail.images.blocks import ImageChooserBlock


# =============================================================================
# BASE PAGE CLASS - All sidor ärver från denna
# =============================================================================
class BasePage(Page):
    """Bas-klass för alla sidor med automatisk slug-konvertering (åäö → aao)"""
    
    class Meta:
        abstract = True
    
    def save(self, *args, **kwargs):
        # Konvertera åäö → aao automatiskt i slug
        if self.title and not self.slug:
            self.slug = slugify(self.title, allow_unicode=False)
        elif self.slug:
            self.slug = slugify(self.slug, allow_unicode=False)
        super().save(*args, **kwargs)


# =============================================================================
# HOME PAGE
# =============================================================================
class HomePage(BasePage):
    """Startsida med hero, tjänster och Instagram"""
    
    # Hero section
    hero_title = models.CharField(
        max_length=255,
        default="Din Auktoriserade Redovisningsbyrå",
        verbose_name="Hero rubrik"
    )
    hero_subtitle = RichTextField(
        blank=True,
        verbose_name="Hero undertext"
    )
    hero_cta_text = models.CharField(
        max_length=100,
        default="Kontakta oss",
        verbose_name="Knapptext"
    )
    hero_image = models.ForeignKey(
        'wagtailimages.Image',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='+',
        verbose_name="Hero bild"
    )
    
    # Main content
    body = StreamField([
        ('heading', blocks.CharBlock(
            form_classname="title",
            icon='title',
            label='Rubrik'
        )),
        ('paragraph', blocks.RichTextBlock(
            label='Paragraf'
        )),
        ('image', ImageChooserBlock(
            label='Bild'
        )),
        ('services', blocks.StructBlock([
            ('title', blocks.CharBlock(label='Rubrik')),
            ('services', blocks.ListBlock(
                blocks.StructBlock([
                    ('icon', blocks.CharBlock(
                        help_text='Lucide icon namn (t.ex. calculator, users, file-text)',
                        label='Ikon'
                    )),
                    ('title', blocks.CharBlock(label='Titel')),
                    ('description', blocks.TextBlock(label='Beskrivning')),
                ])
            ))
        ], icon='list-ul', label='Tjänster')),
    ], blank=True, use_json_field=True, verbose_name="Innehåll")
    
    # Instagram
    show_instagram = models.BooleanField(
        default=True,
        verbose_name="Visa Instagram-flöde"
    )
    
    content_panels = Page.content_panels + [
        FieldPanel('hero_title'),
        FieldPanel('hero_subtitle'),
        FieldPanel('hero_cta_text'),
        FieldPanel('hero_image'),
        FieldPanel('body'),
        FieldPanel('show_instagram'),
    ]
    
    class Meta:
        verbose_name = "Startsida"


# =============================================================================
# SERVICES PAGE
# =============================================================================
class ServicesPage(BasePage):
    """Tjänstesida med lista av tjänster"""
    
    intro = RichTextField(
        blank=True,
        verbose_name="Introduktion"
    )
    
    # StreamField för tjänster
    services = StreamField([
        ('service', blocks.StructBlock([
            ('icon', blocks.CharBlock(
                help_text='Lucide icon namn (t.ex. calculator, users, file-text)',
                label='Ikon'
            )),
            ('title', blocks.CharBlock(label='Titel')),
            ('description', blocks.TextBlock(label='Beskrivning')),
            ('features', blocks.ListBlock(
                blocks.CharBlock(label='Funktion'),
                label='Funktioner/Fördelar'
            )),
            ('price_info', blocks.CharBlock(
                required=False,
                label='Prisinformation',
                help_text='T.ex. "Från 2000 kr/mån" (valfritt)'
            )),
            ('cta_text', blocks.CharBlock(
                default='Läs mer',
                label='Knapptext'
            )),
            ('cta_link', blocks.URLBlock(
                required=False,
                label='Knapp-länk (valfritt)'
            )),
        ], icon='briefcase', label='Tjänst'))
    ], blank=True, use_json_field=True, verbose_name="Tjänster")
    
    content_panels = Page.content_panels + [
        FieldPanel('intro'),
        FieldPanel('services'),
    ]
    
    class Meta:
        verbose_name = "Tjänstesida"